<?php

    $servidor= "localhost";
    $usuario= "root";
    $senha= "";
    $banco= "prova2";

    $con = new mysqli($servidor, $usuario, $senha, $banco);

    
?>